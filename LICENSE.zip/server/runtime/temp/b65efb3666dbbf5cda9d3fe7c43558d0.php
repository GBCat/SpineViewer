<?php /*a:1:{s:48:"C:\GitHub\maictouchphp\app\view\index\index.html";i:1652438481;}*/ ?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>

<body>
	<form action="/index/upload" enctype="multipart/form-data" method="post">
		<input type="file" name="png" accept=".png" multiple="multiple">
		<input type="file" name="atlas" accept=".atlas" multiple="multiple">
		<input type="file" name="json" accept=".json" multiple="multiple">
		<button type="submit">提交</button>
	</form>
</body>

</html>