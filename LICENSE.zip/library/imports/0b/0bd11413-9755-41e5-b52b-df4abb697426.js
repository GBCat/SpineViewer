"use strict";
cc._RF.push(module, '0bd11QTl1VB5bUr30q7aXQm', 'Main');
// Main.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.aniBtn = null;
        _this.backNode = null;
        _this.spine = null;
        _this.name = null;
        _this.track = 0;
        _this.alpha = false;
        return _this;
    }
    /**
     * 从当前URL中获取参数
     * @param name 参数名称,如果不指定参数名称则返回全部参数
     * @returns 值
     */
    Main.prototype.getUrlParam = function (name) {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = {};
        if (url.indexOf("?") != -1) {
            var str = url.substring(1);
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        if (name)
            return theRequest[name];
    };
    Main.prototype.getWindowParam = function (key) {
        return window[key];
    };
    Main.prototype.onLoad = function () {
        var _this = this;
        window['cocos'] = {
            setName: function (name) {
                _this.name = name;
                _this.spine.setAnimation(_this.track, _this.name, true);
            },
            setColor: function (str) {
                var color = new cc.Color();
                cc.Color.fromHEX(color, str);
                _this.backNode.color = color;
            },
            setTrack: function (track) {
                _this.track = track;
                _this.spine.setAnimation(_this.track, _this.name, true);
            },
            setAlpha: function (alpha) {
                _this.spine.premultipliedAlpha = alpha;
            },
        };
        var data = {
            json: this.getWindowParam('json'),
            png: this.getWindowParam('png'),
            atlas: this.getWindowParam('atlas')
        };
        this.loadRemote(data, function (json, png, atlas) {
            console.log('加载完成');
            var text = atlas.text;
            var arr = text.split('\n');
            var name = arr[1];
            var node = new cc.Node();
            node.parent = _this.node;
            var spine = node.addComponent(sp.Skeleton);
            _this.spine = spine;
            var skeletonData = new sp.SkeletonData();
            skeletonData.skeletonJson = json.json;
            skeletonData.textures.push(png);
            skeletonData.atlasText = atlas.text;
            skeletonData.textureNames.push(name);
            spine.skeletonData = skeletonData;
            var actionNames = [];
            for (var key in json.json.animations) {
                actionNames.push(key);
            }
            _this.name = actionNames[0];
            spine.setAnimation(0, actionNames[0], true);
            _this.createAniBtns(actionNames);
            _this.setTouch();
        });
    };
    Main.prototype.createAniBtns = function (list) {
        window['func'].aniList(list);
    };
    Main.prototype.loadRemote = function (urls, call) {
        var json = null;
        var png = null;
        var atlas = null;
        var check = function () {
            if (png && json && atlas) {
                call(json, png, atlas);
            }
        };
        cc.assetManager.loadRemote(urls.png, function (err, res) {
            if (err)
                return;
            png = res;
            check();
        });
        cc.assetManager.loadRemote(urls.json, function (err, res) {
            if (err)
                return;
            json = res;
            check();
        });
        cc.assetManager.loadRemote(urls.atlas, function (err, res) {
            if (err)
                return;
            atlas = res;
            check();
        });
    };
    Main.prototype.setTouch = function () {
        var _this = this;
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (res) {
            _this.spine.node.x += res.getDelta().x;
            _this.spine.node.y += res.getDelta().y;
        });
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, function (res) {
            console.log(res.keyCode);
        });
        this.node.on(cc.Node.EventType.MOUSE_WHEEL, function (res) {
            _this.spine.node.scale += res.getScrollY() / 1200;
            if (_this.spine.node.scale < 0.1)
                _this.spine.node.scale = 0.1;
            console.log(res.getScrollY());
        });
    };
    __decorate([
        property({ type: cc.Prefab })
    ], Main.prototype, "aniBtn", void 0);
    __decorate([
        property({ type: cc.Node })
    ], Main.prototype, "backNode", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();