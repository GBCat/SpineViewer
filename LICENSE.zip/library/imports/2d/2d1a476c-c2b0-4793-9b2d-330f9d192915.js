"use strict";
cc._RF.push(module, '2d1a4dswrBHk5stMw+dGSkV', 'Request');
// Request.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Request = /** @class */ (function (_super) {
    __extends(Request, _super);
    /**
     * 如果在window['apiDoMain']设置了域名
     * 则覆盖掉private domain
     */
    function Request() {
        var _this = _super.call(this) || this;
        /**
         * 域名
         */
        _this.domain = 'https://spine.sunstones.cc/'; //测试域名
        // private domain: string = 'https://hotel.game.quanminxiaodian.com/index.php/api/';//测试域名
        /**
         * 超时时间
         */
        _this.timeout = 5000;
        /**
         * 开启超时重试
         */
        _this.retry = true;
        /**
         * 超时重试次数上限
         */
        _this.retryTime = 2;
        /**
         * 访问类型
         */
        _this.type = 'POST';
        if (window['apiDoMain'] != '' && window['apiDoMain'] != null) {
            _this.domain = window['apiDoMain'];
        }
        return _this;
    }
    Request_1 = Request;
    Request.getApp = function () {
        !this.request ? this.request = new Request_1() : 1;
        return this.request;
    };
    /**
     * 访问接口
     * @param route 访问路径
     * @param data 发送的数据
     * @param call 回调
     */
    Request.prototype.open = function (route, data, call, retry) {
        var _this = this;
        if (data === void 0) { data = null; }
        if (call === void 0) { call = function () { }; }
        if (retry === void 0) { retry = 0; }
        var xhr = new XMLHttpRequest();
        xhr.timeout = this.timeout;
        xhr.onload = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var json = void 0;
                try {
                    json = JSON.parse(xhr.responseText);
                }
                catch (error) {
                    json = xhr.responseText;
                }
                call(json);
            }
            else {
                if (_this.retry) {
                    if (retry >= _this.retryTime) {
                    }
                    else {
                        _this.scheduleOnce(function () {
                            _this.open(route, data, call, retry + 1);
                        }, 0.5);
                    }
                }
            }
        };
        xhr.ontimeout = function () {
            if (_this.retry) {
                if (retry >= _this.retryTime) {
                }
                else {
                    _this.open(route, data, call, retry + 1);
                }
            }
        };
        xhr.onerror = function (err) {
        };
        var str = null;
        if (data)
            str = JSON.stringify(data);
        var timeStamp = this.getTimeStamp();
        // let sign = this.getSign(str, timeStamp);
        xhr.open(this.type, this.domain + route, true);
        xhr.send(str);
    };
    Request.prototype.getTimeStamp = function () {
        var timeStamp = Date.parse(new Date() + '') / 1000;
        return timeStamp;
    };
    Request.prototype.getCookie = function (name) {
        var cookie = document.cookie;
        var cookieArr = cookie.split('; ');
        var arr = new Array();
        cookieArr.forEach(function (res) {
            var test = res.split('=');
            arr[test[0]] = test[1];
        });
        if (arr[name]) {
            return (arr[name]);
        }
        else {
            return null;
        }
    };
    var Request_1;
    Request.request = null;
    Request = Request_1 = __decorate([
        ccclass
    ], Request);
    return Request;
}(cc.Component));
exports.default = Request;

cc._RF.pop();