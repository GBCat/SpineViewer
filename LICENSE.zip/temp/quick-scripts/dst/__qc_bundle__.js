
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Main');
require('./assets/Request');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Request.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2d1a4dswrBHk5stMw+dGSkV', 'Request');
// Request.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Request = /** @class */ (function (_super) {
    __extends(Request, _super);
    /**
     * 如果在window['apiDoMain']设置了域名
     * 则覆盖掉private domain
     */
    function Request() {
        var _this = _super.call(this) || this;
        /**
         * 域名
         */
        _this.domain = 'https://spine.sunstones.cc/'; //测试域名
        // private domain: string = 'https://hotel.game.quanminxiaodian.com/index.php/api/';//测试域名
        /**
         * 超时时间
         */
        _this.timeout = 5000;
        /**
         * 开启超时重试
         */
        _this.retry = true;
        /**
         * 超时重试次数上限
         */
        _this.retryTime = 2;
        /**
         * 访问类型
         */
        _this.type = 'POST';
        if (window['apiDoMain'] != '' && window['apiDoMain'] != null) {
            _this.domain = window['apiDoMain'];
        }
        return _this;
    }
    Request_1 = Request;
    Request.getApp = function () {
        !this.request ? this.request = new Request_1() : 1;
        return this.request;
    };
    /**
     * 访问接口
     * @param route 访问路径
     * @param data 发送的数据
     * @param call 回调
     */
    Request.prototype.open = function (route, data, call, retry) {
        var _this = this;
        if (data === void 0) { data = null; }
        if (call === void 0) { call = function () { }; }
        if (retry === void 0) { retry = 0; }
        var xhr = new XMLHttpRequest();
        xhr.timeout = this.timeout;
        xhr.onload = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var json = void 0;
                try {
                    json = JSON.parse(xhr.responseText);
                }
                catch (error) {
                    json = xhr.responseText;
                }
                call(json);
            }
            else {
                if (_this.retry) {
                    if (retry >= _this.retryTime) {
                    }
                    else {
                        _this.scheduleOnce(function () {
                            _this.open(route, data, call, retry + 1);
                        }, 0.5);
                    }
                }
            }
        };
        xhr.ontimeout = function () {
            if (_this.retry) {
                if (retry >= _this.retryTime) {
                }
                else {
                    _this.open(route, data, call, retry + 1);
                }
            }
        };
        xhr.onerror = function (err) {
        };
        var str = null;
        if (data)
            str = JSON.stringify(data);
        var timeStamp = this.getTimeStamp();
        // let sign = this.getSign(str, timeStamp);
        xhr.open(this.type, this.domain + route, true);
        xhr.send(str);
    };
    Request.prototype.getTimeStamp = function () {
        var timeStamp = Date.parse(new Date() + '') / 1000;
        return timeStamp;
    };
    Request.prototype.getCookie = function (name) {
        var cookie = document.cookie;
        var cookieArr = cookie.split('; ');
        var arr = new Array();
        cookieArr.forEach(function (res) {
            var test = res.split('=');
            arr[test[0]] = test[1];
        });
        if (arr[name]) {
            return (arr[name]);
        }
        else {
            return null;
        }
    };
    var Request_1;
    Request.request = null;
    Request = Request_1 = __decorate([
        ccclass
    ], Request);
    return Request;
}(cc.Component));
exports.default = Request;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcUmVxdWVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUk1QztJQUFxQywyQkFBWTtJQUdoRDs7O09BR0c7SUFDSDtRQUFBLFlBQ0MsaUJBQU8sU0FJUDtRQVdEOztXQUVHO1FBQ0ksWUFBTSxHQUFXLDZCQUE2QixDQUFDLENBQUEsTUFBTTtRQUM1RCwwRkFBMEY7UUFHMUY7O1dBRUc7UUFDSyxhQUFPLEdBQVcsSUFBSSxDQUFDO1FBRy9COztXQUVHO1FBQ0ssV0FBSyxHQUFZLElBQUksQ0FBQztRQUc5Qjs7V0FFRztRQUNLLGVBQVMsR0FBVyxDQUFDLENBQUM7UUFHOUI7O1dBRUc7UUFDSyxVQUFJLEdBQVcsTUFBTSxDQUFDO1FBMUM3QixJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksRUFBRTtZQUM3RCxLQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUNsQzs7SUFDRixDQUFDO2dCQVptQixPQUFPO0lBY3BCLGNBQU0sR0FBYjtRQUNDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLFNBQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ3JCLENBQUM7SUFxQ0Q7Ozs7O09BS0c7SUFDSCxzQkFBSSxHQUFKLFVBQUssS0FBYSxFQUFFLElBQWdCLEVBQUUsSUFBMEIsRUFBRSxLQUFpQjtRQUFuRixpQkF1Q0M7UUF2Q21CLHFCQUFBLEVBQUEsV0FBZ0I7UUFBRSxxQkFBQSxFQUFBLHFCQUF5QixDQUFDO1FBQUUsc0JBQUEsRUFBQSxTQUFpQjtRQUNsRixJQUFJLEdBQUcsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1FBQy9CLEdBQUcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUMzQixHQUFHLENBQUMsTUFBTSxHQUFHO1lBQ1osSUFBSSxHQUFHLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsTUFBTSxJQUFJLEdBQUcsRUFBRTtnQkFDN0MsSUFBSSxJQUFJLFNBQUEsQ0FBQztnQkFDVCxJQUFJO29CQUNILElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDcEM7Z0JBQUMsT0FBTyxLQUFLLEVBQUU7b0JBQ2YsSUFBSSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7aUJBQ3hCO2dCQUNELElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNYO2lCQUFNO2dCQUNOLElBQUksS0FBSSxDQUFDLEtBQUssRUFBRTtvQkFDZixJQUFJLEtBQUssSUFBSSxLQUFJLENBQUMsU0FBUyxFQUFFO3FCQUM1Qjt5QkFBTTt3QkFDTixLQUFJLENBQUMsWUFBWSxDQUFDOzRCQUNqQixLQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDekMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO3FCQUNSO2lCQUNEO2FBQ0Q7UUFDRixDQUFDLENBQUM7UUFDRixHQUFHLENBQUMsU0FBUyxHQUFHO1lBQ2YsSUFBSSxLQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNmLElBQUksS0FBSyxJQUFJLEtBQUksQ0FBQyxTQUFTLEVBQUU7aUJBQzVCO3FCQUFNO29CQUNOLEtBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUN4QzthQUNEO1FBQ0YsQ0FBQyxDQUFBO1FBQ0QsR0FBRyxDQUFDLE9BQU8sR0FBRyxVQUFDLEdBQVE7UUFDdkIsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQ2YsSUFBSSxJQUFJO1lBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BDLDJDQUEyQztRQUMzQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDL0MsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNmLENBQUM7SUFHRCw4QkFBWSxHQUFaO1FBQ0MsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNuRCxPQUFPLFNBQVMsQ0FBQztJQUNsQixDQUFDO0lBR0QsMkJBQVMsR0FBVCxVQUFVLElBQUk7UUFDYixJQUFJLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBQzdCLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkMsSUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDLFVBQUMsR0FBVztZQUM3QixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUNuQjthQUNJO1lBQ0osT0FBTyxJQUFJLENBQUM7U0FDWjtJQUNGLENBQUM7O0lBdEdNLGVBQU8sR0FBWSxJQUFJLENBQUM7SUFwQlgsT0FBTztRQUgzQixPQUFPO09BR2EsT0FBTyxDQTJIM0I7SUFBRCxjQUFDO0NBM0hELEFBMkhDLENBM0hvQyxFQUFFLENBQUMsU0FBUyxHQTJIaEQ7a0JBM0hvQixPQUFPIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuQGNjY2xhc3NcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXF1ZXN0IGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcblxyXG5cdC8qKlxyXG5cdCAqIOWmguaenOWcqHdpbmRvd1snYXBpRG9NYWluJ13orr7nva7kuobln5/lkI1cclxuXHQgKiDliJnopobnm5bmjolwcml2YXRlIGRvbWFpblxyXG5cdCAqL1xyXG5cdGNvbnN0cnVjdG9yKCkge1xyXG5cdFx0c3VwZXIoKTtcclxuXHRcdGlmICh3aW5kb3dbJ2FwaURvTWFpbiddICE9ICcnICYmIHdpbmRvd1snYXBpRG9NYWluJ10gIT0gbnVsbCkge1xyXG5cdFx0XHR0aGlzLmRvbWFpbiA9IHdpbmRvd1snYXBpRG9NYWluJ107XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRzdGF0aWMgZ2V0QXBwKCkge1xyXG5cdFx0IXRoaXMucmVxdWVzdCA/IHRoaXMucmVxdWVzdCA9IG5ldyBSZXF1ZXN0KCkgOiAxO1xyXG5cdFx0cmV0dXJuIHRoaXMucmVxdWVzdDtcclxuXHR9XHJcblxyXG5cclxuXHRzdGF0aWMgcmVxdWVzdDogUmVxdWVzdCA9IG51bGw7XHJcblxyXG5cclxuXHQvKipcclxuXHQgKiDln5/lkI1cclxuXHQgKi9cclxuXHRwdWJsaWMgZG9tYWluOiBzdHJpbmcgPSAnaHR0cHM6Ly9zcGluZS5zdW5zdG9uZXMuY2MvJzsvL+a1i+ivleWfn+WQjVxyXG5cdC8vIHByaXZhdGUgZG9tYWluOiBzdHJpbmcgPSAnaHR0cHM6Ly9ob3RlbC5nYW1lLnF1YW5taW54aWFvZGlhbi5jb20vaW5kZXgucGhwL2FwaS8nOy8v5rWL6K+V5Z+f5ZCNXHJcblxyXG5cclxuXHQvKipcclxuXHQgKiDotoXml7bml7bpl7RcclxuXHQgKi9cclxuXHRwcml2YXRlIHRpbWVvdXQ6IG51bWJlciA9IDUwMDA7XHJcblxyXG5cclxuXHQvKipcclxuXHQgKiDlvIDlkK/otoXml7bph43or5VcclxuXHQgKi9cclxuXHRwcml2YXRlIHJldHJ5OiBib29sZWFuID0gdHJ1ZTtcclxuXHJcblxyXG5cdC8qKlxyXG5cdCAqIOi2heaXtumHjeivleasoeaVsOS4iumZkFxyXG5cdCAqL1xyXG5cdHByaXZhdGUgcmV0cnlUaW1lOiBudW1iZXIgPSAyO1xyXG5cclxuXHJcblx0LyoqXHJcblx0ICog6K6/6Zeu57G75Z6LXHJcblx0ICovXHJcblx0cHJpdmF0ZSB0eXBlOiBzdHJpbmcgPSAnUE9TVCc7XHJcblxyXG5cclxuXHQvKipcclxuXHQgKiDorr/pl67mjqXlj6NcclxuXHQgKiBAcGFyYW0gcm91dGUg6K6/6Zeu6Lev5b6EXHJcblx0ICogQHBhcmFtIGRhdGEg5Y+R6YCB55qE5pWw5o2uXHJcblx0ICogQHBhcmFtIGNhbGwg5Zue6LCDXHJcblx0ICovXHJcblx0b3Blbihyb3V0ZTogc3RyaW5nLCBkYXRhOiBhbnkgPSBudWxsLCBjYWxsOiBGdW5jdGlvbiA9ICgpID0+IHsgfSwgcmV0cnk6IG51bWJlciA9IDApIHtcclxuXHRcdGxldCB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcclxuXHRcdHhoci50aW1lb3V0ID0gdGhpcy50aW1lb3V0O1xyXG5cdFx0eGhyLm9ubG9hZCA9ICgpID0+IHtcclxuXHRcdFx0aWYgKHhoci5yZWFkeVN0YXRlID09IDQgJiYgeGhyLnN0YXR1cyA9PSAyMDApIHtcclxuXHRcdFx0XHRsZXQganNvbjtcclxuXHRcdFx0XHR0cnkge1xyXG5cdFx0XHRcdFx0anNvbiA9IEpTT04ucGFyc2UoeGhyLnJlc3BvbnNlVGV4dCk7XHJcblx0XHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcclxuXHRcdFx0XHRcdGpzb24gPSB4aHIucmVzcG9uc2VUZXh0O1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRjYWxsKGpzb24pO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGlmICh0aGlzLnJldHJ5KSB7XHJcblx0XHRcdFx0XHRpZiAocmV0cnkgPj0gdGhpcy5yZXRyeVRpbWUpIHtcclxuXHRcdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRcdHRoaXMuc2NoZWR1bGVPbmNlKCgpID0+IHtcclxuXHRcdFx0XHRcdFx0XHR0aGlzLm9wZW4ocm91dGUsIGRhdGEsIGNhbGwsIHJldHJ5ICsgMSk7XHJcblx0XHRcdFx0XHRcdH0sIDAuNSk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9O1xyXG5cdFx0eGhyLm9udGltZW91dCA9ICgpID0+IHtcclxuXHRcdFx0aWYgKHRoaXMucmV0cnkpIHtcclxuXHRcdFx0XHRpZiAocmV0cnkgPj0gdGhpcy5yZXRyeVRpbWUpIHtcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0dGhpcy5vcGVuKHJvdXRlLCBkYXRhLCBjYWxsLCByZXRyeSArIDEpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0eGhyLm9uZXJyb3IgPSAoZXJyOiBhbnkpID0+IHtcclxuXHRcdH07XHJcblx0XHRsZXQgc3RyID0gbnVsbDtcclxuXHRcdGlmIChkYXRhKSBzdHIgPSBKU09OLnN0cmluZ2lmeShkYXRhKTtcclxuXHRcdGxldCB0aW1lU3RhbXAgPSB0aGlzLmdldFRpbWVTdGFtcCgpO1xyXG5cdFx0Ly8gbGV0IHNpZ24gPSB0aGlzLmdldFNpZ24oc3RyLCB0aW1lU3RhbXApO1xyXG5cdFx0eGhyLm9wZW4odGhpcy50eXBlLCB0aGlzLmRvbWFpbiArIHJvdXRlLCB0cnVlKTtcclxuXHRcdHhoci5zZW5kKHN0cik7XHJcblx0fVxyXG5cclxuXHJcblx0Z2V0VGltZVN0YW1wKCk6IG51bWJlciB7XHJcblx0XHRsZXQgdGltZVN0YW1wID0gRGF0ZS5wYXJzZShuZXcgRGF0ZSgpICsgJycpIC8gMTAwMDtcclxuXHRcdHJldHVybiB0aW1lU3RhbXA7XHJcblx0fVxyXG5cclxuXHJcblx0Z2V0Q29va2llKG5hbWUpIHtcclxuXHRcdGxldCBjb29raWUgPSBkb2N1bWVudC5jb29raWU7XHJcblx0XHRsZXQgY29va2llQXJyID0gY29va2llLnNwbGl0KCc7ICcpO1xyXG5cdFx0bGV0IGFyciA9IG5ldyBBcnJheSgpO1xyXG5cdFx0Y29va2llQXJyLmZvckVhY2goKHJlczogc3RyaW5nKSA9PiB7XHJcblx0XHRcdGxldCB0ZXN0ID0gcmVzLnNwbGl0KCc9Jyk7XHJcblx0XHRcdGFyclt0ZXN0WzBdXSA9IHRlc3RbMV07XHJcblx0XHR9KTtcclxuXHRcdGlmIChhcnJbbmFtZV0pIHtcclxuXHRcdFx0cmV0dXJuIChhcnJbbmFtZV0pO1xyXG5cdFx0fVxyXG5cdFx0ZWxzZSB7XHJcblx0XHRcdHJldHVybiBudWxsO1xyXG5cdFx0fVxyXG5cdH1cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Main.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0bd11QTl1VB5bUr30q7aXQm', 'Main');
// Main.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.aniBtn = null;
        _this.backNode = null;
        _this.spine = null;
        _this.name = null;
        _this.track = 0;
        _this.alpha = false;
        return _this;
    }
    /**
     * 从当前URL中获取参数
     * @param name 参数名称,如果不指定参数名称则返回全部参数
     * @returns 值
     */
    Main.prototype.getUrlParam = function (name) {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = {};
        if (url.indexOf("?") != -1) {
            var str = url.substring(1);
            var strs = str.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURI(strs[i].split("=")[1]);
            }
        }
        if (name)
            return theRequest[name];
    };
    Main.prototype.getWindowParam = function (key) {
        return window[key];
    };
    Main.prototype.onLoad = function () {
        var _this = this;
        window['cocos'] = {
            setName: function (name) {
                _this.name = name;
                _this.spine.setAnimation(_this.track, _this.name, true);
            },
            setColor: function (str) {
                var color = new cc.Color();
                cc.Color.fromHEX(color, str);
                _this.backNode.color = color;
            },
            setTrack: function (track) {
                _this.track = track;
                _this.spine.setAnimation(_this.track, _this.name, true);
            },
            setAlpha: function (alpha) {
                _this.spine.premultipliedAlpha = alpha;
            },
        };
        var data = {
            json: this.getWindowParam('json'),
            png: this.getWindowParam('png'),
            atlas: this.getWindowParam('atlas')
        };
        this.loadRemote(data, function (json, png, atlas) {
            console.log('加载完成');
            var text = atlas.text;
            var arr = text.split('\n');
            var name = arr[1];
            var node = new cc.Node();
            node.parent = _this.node;
            var spine = node.addComponent(sp.Skeleton);
            _this.spine = spine;
            var skeletonData = new sp.SkeletonData();
            skeletonData.skeletonJson = json.json;
            skeletonData.textures.push(png);
            skeletonData.atlasText = atlas.text;
            skeletonData.textureNames.push(name);
            spine.skeletonData = skeletonData;
            var actionNames = [];
            for (var key in json.json.animations) {
                actionNames.push(key);
            }
            _this.name = actionNames[0];
            spine.setAnimation(0, actionNames[0], true);
            _this.createAniBtns(actionNames);
            _this.setTouch();
        });
    };
    Main.prototype.createAniBtns = function (list) {
        window['func'].aniList(list);
    };
    Main.prototype.loadRemote = function (urls, call) {
        var json = null;
        var png = null;
        var atlas = null;
        var check = function () {
            if (png && json && atlas) {
                call(json, png, atlas);
            }
        };
        cc.assetManager.loadRemote(urls.png, function (err, res) {
            if (err)
                return;
            png = res;
            check();
        });
        cc.assetManager.loadRemote(urls.json, function (err, res) {
            if (err)
                return;
            json = res;
            check();
        });
        cc.assetManager.loadRemote(urls.atlas, function (err, res) {
            if (err)
                return;
            atlas = res;
            check();
        });
    };
    Main.prototype.setTouch = function () {
        var _this = this;
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (res) {
            _this.spine.node.x += res.getDelta().x;
            _this.spine.node.y += res.getDelta().y;
        });
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, function (res) {
            console.log(res.keyCode);
        });
        this.node.on(cc.Node.EventType.MOUSE_WHEEL, function (res) {
            _this.spine.node.scale += res.getScrollY() / 1200;
            if (_this.spine.node.scale < 0.1)
                _this.spine.node.scale = 0.1;
            console.log(res.getScrollY());
        });
    };
    __decorate([
        property({ type: cc.Prefab })
    ], Main.prototype, "aniBtn", void 0);
    __decorate([
        property({ type: cc.Node })
    ], Main.prototype, "backNode", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcTWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFTSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFrQyx3QkFBWTtJQUE5QztRQUFBLHFFQW9JQztRQWpJQSxZQUFNLEdBQWMsSUFBSSxDQUFDO1FBRXpCLGNBQVEsR0FBWSxJQUFJLENBQUM7UUFHekIsV0FBSyxHQUFnQixJQUFJLENBQUM7UUF1QjFCLFVBQUksR0FBVyxJQUFJLENBQUM7UUFDcEIsV0FBSyxHQUFXLENBQUMsQ0FBQztRQUNsQixXQUFLLEdBQVksS0FBSyxDQUFDOztJQW1HeEIsQ0FBQztJQTNIQTs7OztPQUlHO0lBQ0gsMEJBQVcsR0FBWCxVQUFZLElBQWE7UUFDeEIsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGdCQUFnQjtRQUMzQyxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDcEIsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQzNCLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDckMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3JFO1NBQ0Q7UUFDRCxJQUFJLElBQUk7WUFBRSxPQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRUQsNkJBQWMsR0FBZCxVQUFlLEdBQVc7UUFDekIsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUtELHFCQUFNLEdBQU47UUFBQSxpQkFpREM7UUFoREEsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHO1lBQ2pCLE9BQU8sRUFBRSxVQUFDLElBQUk7Z0JBQ2IsS0FBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBQ2pCLEtBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN0RCxDQUFDO1lBQ0QsUUFBUSxFQUFFLFVBQUMsR0FBRztnQkFDYixJQUFJLEtBQUssR0FBYSxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDckMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUM3QixLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDN0IsQ0FBQztZQUNELFFBQVEsRUFBRSxVQUFDLEtBQUs7Z0JBQ2YsS0FBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ25CLEtBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN0RCxDQUFDO1lBQ0QsUUFBUSxFQUFFLFVBQUMsS0FBSztnQkFDZixLQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztZQUN2QyxDQUFDO1NBQ0QsQ0FBQztRQUNGLElBQUksSUFBSSxHQUFZO1lBQ25CLElBQUksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUNqQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7WUFDL0IsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDO1NBQ25DLENBQUM7UUFDRixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxVQUFDLElBQWtCLEVBQUUsR0FBaUIsRUFBRSxLQUFtQjtZQUNoRixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BCLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7WUFDdEIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzQixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEIsSUFBSSxJQUFJLEdBQVksSUFBSSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3hCLElBQUksS0FBSyxHQUFnQixJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4RCxLQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixJQUFJLFlBQVksR0FBb0IsSUFBSSxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDMUQsWUFBWSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLFlBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hDLFlBQVksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztZQUNwQyxZQUFZLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQyxLQUFLLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztZQUNsQyxJQUFJLFdBQVcsR0FBYSxFQUFFLENBQUM7WUFDL0IsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDckMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUN0QjtZQUNELEtBQUksQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNCLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM1QyxLQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hDLEtBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUVKLENBQUM7SUFHRCw0QkFBYSxHQUFiLFVBQWMsSUFBYztRQUMzQixNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFUyx5QkFBVSxHQUFwQixVQUFxQixJQUFVLEVBQUUsSUFBMEU7UUFDMUcsSUFBSSxJQUFJLEdBQWlCLElBQUksQ0FBQztRQUM5QixJQUFJLEdBQUcsR0FBaUIsSUFBSSxDQUFDO1FBQzdCLElBQUksS0FBSyxHQUFpQixJQUFJLENBQUM7UUFDL0IsSUFBSSxLQUFLLEdBQWU7WUFDdkIsSUFBSSxHQUFHLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRTtnQkFDekIsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDdkI7UUFDRixDQUFDLENBQUM7UUFDRixFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsR0FBRyxFQUFFLEdBQWlCO1lBQzNELElBQUksR0FBRztnQkFBRSxPQUFPO1lBQ2hCLEdBQUcsR0FBRyxHQUFHLENBQUM7WUFDVixLQUFLLEVBQUUsQ0FBQztRQUNULENBQUMsQ0FBQyxDQUFDO1FBQ0gsRUFBRSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLEdBQUcsRUFBRSxHQUFpQjtZQUM1RCxJQUFJLEdBQUc7Z0JBQUUsT0FBTztZQUNoQixJQUFJLEdBQUcsR0FBRyxDQUFDO1lBQ1gsS0FBSyxFQUFFLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBQyxHQUFHLEVBQUUsR0FBaUI7WUFDN0QsSUFBSSxHQUFHO2dCQUFFLE9BQU87WUFDaEIsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUNaLEtBQUssRUFBRSxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUM7SUFDSixDQUFDO0lBRUQsdUJBQVEsR0FBUjtRQUFBLGlCQWFDO1FBWkEsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLFVBQUMsR0FBRztZQUM5QyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN0QyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxDQUFDLENBQUMsQ0FBQztRQUNILEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxVQUFDLEdBQUc7WUFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBQyxHQUFHO1lBQy9DLEtBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxHQUFHLENBQUMsVUFBVSxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ2pELElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUc7Z0JBQUUsS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQTlIRDtRQURDLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7d0NBQ0w7SUFFekI7UUFEQyxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDOzBDQUNIO0lBTEwsSUFBSTtRQUR4QixPQUFPO09BQ2EsSUFBSSxDQW9JeEI7SUFBRCxXQUFDO0NBcElELEFBb0lDLENBcElpQyxFQUFFLENBQUMsU0FBUyxHQW9JN0M7a0JBcElvQixJQUFJIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlcXVlc3QgZnJvbSBcIi4vUmVxdWVzdFwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1haW4gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuXHRAcHJvcGVydHkoeyB0eXBlOiBjYy5QcmVmYWIgfSlcclxuXHRhbmlCdG46IGNjLlByZWZhYiA9IG51bGw7XHJcblx0QHByb3BlcnR5KHsgdHlwZTogY2MuTm9kZSB9KVxyXG5cdGJhY2tOb2RlOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcblxyXG5cdHNwaW5lOiBzcC5Ta2VsZXRvbiA9IG51bGw7XHJcblx0LyoqXHJcblx0ICog5LuO5b2T5YmNVVJM5Lit6I635Y+W5Y+C5pWwXHJcblx0ICogQHBhcmFtIG5hbWUg5Y+C5pWw5ZCN56ewLOWmguaenOS4jeaMh+WumuWPguaVsOWQjeensOWImei/lOWbnuWFqOmDqOWPguaVsFxyXG5cdCAqIEByZXR1cm5zIOWAvFxyXG5cdCAqL1xyXG5cdGdldFVybFBhcmFtKG5hbWU/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG5cdFx0bGV0IHVybCA9IGxvY2F0aW9uLnNlYXJjaDsgLy/ojrflj5Z1cmzkuK1cIj9cIuespuWQjueahOWtl+S4slxyXG5cdFx0bGV0IHRoZVJlcXVlc3QgPSB7fTtcclxuXHRcdGlmICh1cmwuaW5kZXhPZihcIj9cIikgIT0gLTEpIHtcclxuXHRcdFx0bGV0IHN0ciA9IHVybC5zdWJzdHJpbmcoMSk7XHJcblx0XHRcdGxldCBzdHJzID0gc3RyLnNwbGl0KFwiJlwiKTtcclxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzdHJzLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0dGhlUmVxdWVzdFtzdHJzW2ldLnNwbGl0KFwiPVwiKVswXV0gPSBkZWNvZGVVUkkoc3Ryc1tpXS5zcGxpdChcIj1cIilbMV0pO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHRpZiAobmFtZSkgcmV0dXJuIHRoZVJlcXVlc3RbbmFtZV07XHJcblx0fVxyXG5cclxuXHRnZXRXaW5kb3dQYXJhbShrZXk6IHN0cmluZyk6IHN0cmluZyB7XHJcblx0XHRyZXR1cm4gd2luZG93W2tleV07XHJcblx0fVxyXG5cclxuXHRuYW1lOiBzdHJpbmcgPSBudWxsO1xyXG5cdHRyYWNrOiBudW1iZXIgPSAwO1xyXG5cdGFscGhhOiBib29sZWFuID0gZmFsc2U7XHJcblx0b25Mb2FkKCkge1xyXG5cdFx0d2luZG93Wydjb2NvcyddID0ge1xyXG5cdFx0XHRzZXROYW1lOiAobmFtZSkgPT4ge1xyXG5cdFx0XHRcdHRoaXMubmFtZSA9IG5hbWU7XHJcblx0XHRcdFx0dGhpcy5zcGluZS5zZXRBbmltYXRpb24odGhpcy50cmFjaywgdGhpcy5uYW1lLCB0cnVlKTtcclxuXHRcdFx0fSxcclxuXHRcdFx0c2V0Q29sb3I6IChzdHIpID0+IHtcclxuXHRcdFx0XHRsZXQgY29sb3I6IGNjLkNvbG9yID0gbmV3IGNjLkNvbG9yKCk7XHJcblx0XHRcdFx0Y2MuQ29sb3IuZnJvbUhFWChjb2xvciwgc3RyKTtcclxuXHRcdFx0XHR0aGlzLmJhY2tOb2RlLmNvbG9yID0gY29sb3I7XHJcblx0XHRcdH0sXHJcblx0XHRcdHNldFRyYWNrOiAodHJhY2spID0+IHtcclxuXHRcdFx0XHR0aGlzLnRyYWNrID0gdHJhY2s7XHJcblx0XHRcdFx0dGhpcy5zcGluZS5zZXRBbmltYXRpb24odGhpcy50cmFjaywgdGhpcy5uYW1lLCB0cnVlKTtcclxuXHRcdFx0fSxcclxuXHRcdFx0c2V0QWxwaGE6IChhbHBoYSkgPT4ge1xyXG5cdFx0XHRcdHRoaXMuc3BpbmUucHJlbXVsdGlwbGllZEFscGhhID0gYWxwaGE7XHJcblx0XHRcdH0sXHJcblx0XHR9O1xyXG5cdFx0bGV0IGRhdGE6IFJlcVVybHMgPSB7XHJcblx0XHRcdGpzb246IHRoaXMuZ2V0V2luZG93UGFyYW0oJ2pzb24nKSxcclxuXHRcdFx0cG5nOiB0aGlzLmdldFdpbmRvd1BhcmFtKCdwbmcnKSxcclxuXHRcdFx0YXRsYXM6IHRoaXMuZ2V0V2luZG93UGFyYW0oJ2F0bGFzJylcclxuXHRcdH07XHJcblx0XHR0aGlzLmxvYWRSZW1vdGUoZGF0YSwgKGpzb246IGNjLkpzb25Bc3NldCwgcG5nOiBjYy5UZXh0dXJlMkQsIGF0bGFzOiBjYy5UZXh0QXNzZXQpID0+IHtcclxuXHRcdFx0Y29uc29sZS5sb2coJ+WKoOi9veWujOaIkCcpO1xyXG5cdFx0XHRsZXQgdGV4dCA9IGF0bGFzLnRleHQ7XHJcblx0XHRcdGxldCBhcnIgPSB0ZXh0LnNwbGl0KCdcXG4nKTtcclxuXHRcdFx0bGV0IG5hbWUgPSBhcnJbMV07XHJcblx0XHRcdGxldCBub2RlOiBjYy5Ob2RlID0gbmV3IGNjLk5vZGUoKTtcclxuXHRcdFx0bm9kZS5wYXJlbnQgPSB0aGlzLm5vZGU7XHJcblx0XHRcdGxldCBzcGluZTogc3AuU2tlbGV0b24gPSBub2RlLmFkZENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcblx0XHRcdHRoaXMuc3BpbmUgPSBzcGluZTtcclxuXHRcdFx0bGV0IHNrZWxldG9uRGF0YTogc3AuU2tlbGV0b25EYXRhID0gbmV3IHNwLlNrZWxldG9uRGF0YSgpO1xyXG5cdFx0XHRza2VsZXRvbkRhdGEuc2tlbGV0b25Kc29uID0ganNvbi5qc29uO1xyXG5cdFx0XHRza2VsZXRvbkRhdGEudGV4dHVyZXMucHVzaChwbmcpO1xyXG5cdFx0XHRza2VsZXRvbkRhdGEuYXRsYXNUZXh0ID0gYXRsYXMudGV4dDtcclxuXHRcdFx0c2tlbGV0b25EYXRhLnRleHR1cmVOYW1lcy5wdXNoKG5hbWUpO1xyXG5cdFx0XHRzcGluZS5za2VsZXRvbkRhdGEgPSBza2VsZXRvbkRhdGE7XHJcblx0XHRcdGxldCBhY3Rpb25OYW1lczogc3RyaW5nW10gPSBbXTtcclxuXHRcdFx0Zm9yIChsZXQga2V5IGluIGpzb24uanNvbi5hbmltYXRpb25zKSB7XHJcblx0XHRcdFx0YWN0aW9uTmFtZXMucHVzaChrZXkpO1xyXG5cdFx0XHR9XHJcblx0XHRcdHRoaXMubmFtZSA9IGFjdGlvbk5hbWVzWzBdO1xyXG5cdFx0XHRzcGluZS5zZXRBbmltYXRpb24oMCwgYWN0aW9uTmFtZXNbMF0sIHRydWUpO1xyXG5cdFx0XHR0aGlzLmNyZWF0ZUFuaUJ0bnMoYWN0aW9uTmFtZXMpO1xyXG5cdFx0XHR0aGlzLnNldFRvdWNoKCk7XHJcblx0XHR9KTtcclxuXHJcblx0fVxyXG5cclxuXHJcblx0Y3JlYXRlQW5pQnRucyhsaXN0OiBzdHJpbmdbXSkge1xyXG5cdFx0d2luZG93WydmdW5jJ10uYW5pTGlzdChsaXN0KTtcclxuXHR9XHJcblxyXG5cdHByb3RlY3RlZCBsb2FkUmVtb3RlKHVybHM6IFVybHMsIGNhbGw6IChqc29uOiBjYy5Kc29uQXNzZXQsIHBuZzogY2MuVGV4dHVyZTJELCBhdGxhczogY2MuVGV4dEFzc2V0KSA9PiB2b2lkKSB7XHJcblx0XHRsZXQganNvbjogY2MuSnNvbkFzc2V0ID0gbnVsbDtcclxuXHRcdGxldCBwbmc6IGNjLlRleHR1cmUyRCA9IG51bGw7XHJcblx0XHRsZXQgYXRsYXM6IGNjLlRleHRBc3NldCA9IG51bGw7XHJcblx0XHRsZXQgY2hlY2s6ICgpID0+IHZvaWQgPSAoKSA9PiB7XHJcblx0XHRcdGlmIChwbmcgJiYganNvbiAmJiBhdGxhcykge1xyXG5cdFx0XHRcdGNhbGwoanNvbiwgcG5nLCBhdGxhcyk7XHJcblx0XHRcdH1cclxuXHRcdH07XHJcblx0XHRjYy5hc3NldE1hbmFnZXIubG9hZFJlbW90ZSh1cmxzLnBuZywgKGVyciwgcmVzOiBjYy5UZXh0dXJlMkQpID0+IHtcclxuXHRcdFx0aWYgKGVycikgcmV0dXJuO1xyXG5cdFx0XHRwbmcgPSByZXM7XHJcblx0XHRcdGNoZWNrKCk7XHJcblx0XHR9KTtcclxuXHRcdGNjLmFzc2V0TWFuYWdlci5sb2FkUmVtb3RlKHVybHMuanNvbiwgKGVyciwgcmVzOiBjYy5Kc29uQXNzZXQpID0+IHtcclxuXHRcdFx0aWYgKGVycikgcmV0dXJuO1xyXG5cdFx0XHRqc29uID0gcmVzO1xyXG5cdFx0XHRjaGVjaygpO1xyXG5cdFx0fSk7XHJcblx0XHRjYy5hc3NldE1hbmFnZXIubG9hZFJlbW90ZSh1cmxzLmF0bGFzLCAoZXJyLCByZXM6IGNjLlRleHRBc3NldCkgPT4ge1xyXG5cdFx0XHRpZiAoZXJyKSByZXR1cm47XHJcblx0XHRcdGF0bGFzID0gcmVzO1xyXG5cdFx0XHRjaGVjaygpO1xyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRzZXRUb3VjaCgpIHtcclxuXHRcdHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCAocmVzKSA9PiB7XHJcblx0XHRcdHRoaXMuc3BpbmUubm9kZS54ICs9IHJlcy5nZXREZWx0YSgpLng7XHJcblx0XHRcdHRoaXMuc3BpbmUubm9kZS55ICs9IHJlcy5nZXREZWx0YSgpLnk7XHJcblx0XHR9KTtcclxuXHRcdGNjLnN5c3RlbUV2ZW50Lm9uKGNjLlN5c3RlbUV2ZW50LkV2ZW50VHlwZS5LRVlfRE9XTiwgKHJlcykgPT4ge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhyZXMua2V5Q29kZSk7XHJcblx0XHR9KTtcclxuXHRcdHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9XSEVFTCwgKHJlcykgPT4ge1xyXG5cdFx0XHR0aGlzLnNwaW5lLm5vZGUuc2NhbGUgKz0gcmVzLmdldFNjcm9sbFkoKSAvIDEyMDA7XHJcblx0XHRcdGlmICh0aGlzLnNwaW5lLm5vZGUuc2NhbGUgPCAwLjEpIHRoaXMuc3BpbmUubm9kZS5zY2FsZSA9IDAuMTtcclxuXHRcdFx0Y29uc29sZS5sb2cocmVzLmdldFNjcm9sbFkoKSk7XHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cclxufVxyXG5leHBvcnQgdHlwZSBVcmxzID0ge1xyXG5cdHBuZzogc3RyaW5nLFxyXG5cdGpzb246IHN0cmluZyxcclxuXHRhdGxhczogc3RyaW5nXHJcbn07XHJcbmV4cG9ydCB0eXBlIFJlcVVybHMgPSB7XHJcblx0cG5nOiBzdHJpbmcsXHJcblx0anNvbjogc3RyaW5nLFxyXG5cdGF0bGFzOiBzdHJpbmcsXHJcbn07Il19
//------QC-SOURCE-SPLIT------
